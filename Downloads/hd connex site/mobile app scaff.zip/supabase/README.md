
# HD Connex — Supabase Backend

## What this gives you
- Postgres schema for users, contractors, leads, projects, reviews
- RLS policies for basic security
- Seed data for local testing
- Three Edge Functions:
  - `upsert_lead` (create a lead with validation + optional assignment)
  - `search_contractors` (filter by county, service, text)
  - `post_review` (validated review creation)

## What you still need to do
- TODO(secrets): Set `SUPABASE_URL` and keys in local `.env` and on your hosting.
- TODO(auth): Configure email auth and custom SMTP or use magic links.
- TODO(anti-abuse): Put Turnstile/reCAPTCHA in front of public lead creation.
- TODO(observability): Add logs, rate limits, and alerting (see commented sections in functions).
- TODO(admin): Decide how admin actions are authorized (JWT claim or Postgres role).

## Apply locally
1. Create a new Supabase project.
2. Run the SQL files in order:
   1. `schema.sql`
   2. `policies.sql`
   3. `seed.sql` (optional)
3. Deploy edge functions:
   ```bash
   supabase functions deploy upsert_lead
   supabase functions deploy search_contractors
   supabase functions deploy post_review
   ```
4. Expose the function URLs as `/functions/v1/<name>`.
