/**
 * TODO: Requires a running React Native app built with Detox config above.
 */
describe('App bootstrap', () => {
  it('shows Login on first screen', async () => {
    await device.launchApp();
    await expect(element(by.text('Login'))).toBeVisible();
  });
});
