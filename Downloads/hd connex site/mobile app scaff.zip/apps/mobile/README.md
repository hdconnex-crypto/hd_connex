# HDConnex Mobile (Expo)

Scaffold created 2025-08-27T21:49:26.878703Z.

## Run
```bash
cd apps/mobile
npm install
npm run start
# press i for iOS simulator, a for Android, w for web
```

## Env
Copy `.env.example` to `.env` and fill `API_BASE_URL`.
