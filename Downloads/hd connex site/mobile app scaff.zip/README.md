# HD Connex – Platform Scope, Stack, and Scaffolding

This bundle includes:
- **docs/requirements.md**: Requirements, scope, roles, features, data models.
- **package.json** with npm workspaces for `apps/*` and `packages/*`.
- **tsconfig.base.json** with strict defaults.
- **.eslintrc.cjs** and **.prettierrc.json** wired for TS, React, React Native.
- **.github/workflows/ci.yml** for lint + type check on push/PR.
- **packages/db/prisma/schema.prisma** with first-pass data model.
- App-level ESLint stubs under `apps/web` and `apps/mobile`.

> You can generate codebases with:
> ```bash
> # Web
> npx create-next-app@latest apps/web --ts --eslint --use-npm
> # Mobile
> npx create-expo-app apps/mobile
> ```
> Then wire to the root config by keeping package names and tsconfig paths as written here.

## Quickstart
```bash
npm i
npm run lint
npm run typecheck
```
