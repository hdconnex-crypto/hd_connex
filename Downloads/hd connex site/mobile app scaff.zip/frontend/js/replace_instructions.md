
# How to wire the current index.html to the API

1) Add the following `<script>` tags near the top of `<body>` *before* your big `type="text/babel"` script:
```html
<script type="module" src="/js/supabaseClient.js"></script>
<script src="/js/apiClient.js"></script>
<script type="text/babel" src="/js/authContext.jsx"></script>
```
2) Replace hard-coded sample data:
   - `contractorProfiles` -> call `searchContractors({ service, county, q })` and `getContractorById(id)`.
   - `reviewsData` -> call `listReviews(contractorId)`.
   - Lead form `handleSubmit` -> call `createLead(formData)` and show success on `{ ok: true }`.

3) Minimal example inside your existing `<script type="text/babel">`:
```jsx
// LeadCaptureForm.handleSubmit
const handleSubmit = async () => {
  const payload = {
    service: formData.service, county: formData.county, city: formData.city,
    details: formData.details, name: formData.name, email: formData.email,
    phone: formData.phone, smsOptOut: formData.smsOptOut,
  };
  const res = await createLead(payload);
  if (res.ok) setIsSubmitted(true);
  else alert(res.error || 'Failed to submit lead');
};
```

4) Auth later:
   - Add login UI and call `signInWithEmail(email, password)`.
   - Wrap your root app with `<AuthProvider>` and read `user` from `AuthContext` when needed.

5) Environment:
   - Replace all `YOUR-PROJECT` and keys in `/js/*.js` and `/openapi/openapi.yaml`.
   - Deploy edge functions and confirm URLs resolve at `/functions/v1/<name>`.

## TODOs still on you and why
- CAPTCHA: to prevent spam since lead insert is public.
- Admin claim in JWT: to approve contractors securely.
- Storage buckets: for contractor logos and project photos.
- Webhooks or notifications: to alert contractors on new leads.
- CI/CD: migrations applied automatically; refresh ratings if you later materialize them.
