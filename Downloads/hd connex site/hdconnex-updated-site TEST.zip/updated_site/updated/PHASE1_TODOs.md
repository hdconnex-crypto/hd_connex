# Phase One TODOs (Unfinished due to external constraints)

These items remain incomplete and require external inputs or decisions:

1. **Authentication & RBAC**
   - Blocked on: Provider choice (NextAuth, Clerk, Auth0, custom).
   - Needed: Decide on flows (email/OTP, OAuth) and user policies.

2. **Stripe Integration**
   - Blocked on: Stripe API keys, webhook setup, dunning policies.
   - Needed: Live/test keys, endpoint wiring, product/plan config.

3. **Realtime Messaging**
   - Blocked on: Transport choice (Pusher, Ably, Socket.IO, WebSocket infra).
   - Needed: Decide infra, provision service, set env secrets.

4. **Job Scheduling**
   - Blocked on: Calendar provider and timezone policy.
   - Needed: Decide integration (Google Calendar, custom), handle timezones and daylight saving.

5. **Review Verification**
   - Blocked on: Business rules and moderation policy.
   - Needed: Define criteria for verified review, fraud detection rules.

6. **DevOps / Infra**
   - Blocked on: Domains, secrets, environment configuration.
   - Needed: Deployment targets, secret management, monitoring, logging.

## Next Action
Until these are decided, the foundation codebase and schema are ready to develop core features.
