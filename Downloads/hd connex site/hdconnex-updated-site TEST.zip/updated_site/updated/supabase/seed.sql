
-- Minimal seed to test the flows. Replace email addresses with your test users in Supabase Auth.
-- NOTE: auth.users cannot be inserted directly; create accounts via Supabase Auth or Admin API.

-- Example contractors (approved + pending)
insert into public.contractors (
  owner_auth_user_id, company_name, license_number, years_in_business, is_insured, insurance_amount,
  phone, email, website, about, specialties, service_areas, status, rating, total_reviews
) values
  (null, 'Reliable Roofing Inc.', 'RR282828', 15, true, 2000000, '(386) 555-0123', 'info@reliableroofing.com', 'www.reliableroofing.com',
   'Family-owned roofing company serving Central Florida for over 15 years.', array['Roofing','Gutters'], array['Volusia','Flagler'], 'approved', 4.8, 127),
  (null, 'Orlando Pool Masters', 'OPM12345', 8, true, 1500000, '(407) 555-0456', 'contact@orlandopoolmasters.com', 'www.orlandopoolmasters.com',
   'Premier pool installation and maintenance company in the Orlando area.', array['Pools'], array['Orange','Seminole'], 'pending', 4.9, 89)
on conflict do nothing;

-- Example public lead (anonymous)
insert into public.leads (
  service, county, city, details, contact_name, contact_email, contact_phone, sms_opt_out
) values (
  'Roofing','Volusia','Daytona Beach','Need full roof replacement after storm damage','John Smith','john@example.com','(386) 555-0199', false
);
