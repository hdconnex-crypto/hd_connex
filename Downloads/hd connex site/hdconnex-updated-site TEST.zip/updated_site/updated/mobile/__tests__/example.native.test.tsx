import React from 'react';
import { render, screen } from '@testing-library/react-native';
import { Text } from 'react-native';

function Login() {
  return <Text accessibilityRole="header">Login</Text>;
}

it('shows login header', () => {
  render(<Login />);
  expect(screen.getByRole('header', { name: /Login/i })).toBeTruthy();
});
