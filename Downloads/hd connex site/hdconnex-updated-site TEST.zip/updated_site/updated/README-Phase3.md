# Phase 3 – Testing & QA Pack

What you got:
- **Type safety**: `tsconfig.json`. Run `npm run typecheck`.
- **Style gates**: ESLint + Prettier. Run `npm run lint`, `npm run format`.
- **Unit/Integration**: Jest split configs for web and React Native.
- **E2E Web**: Cypress with an example spec.
- **E2E Mobile**: Detox skeleton with iOS and Android configs.
- **CI**: GitHub Actions pipeline running lint, typecheck, unit, and E2E (web now, mobile TODO).

## Install

```bash
npm ci
npx husky install
```

## Commands

```bash
npm run typecheck            # TS checks (no emit)
npm run lint                 # ESLint
npm run format               # Prettier check
npm run test:web             # Jest web tests
npm run test:native          # Jest RN tests
npm run e2e:web              # Cypress
npm run e2e:native           # Detox (after native setup)
```

## File Map

- `.eslintrc.cjs` — ESLint rules with RN overrides.
- `.prettierrc.json` — Prettier.
- `jest.web.config.ts` — Web tests with jsdom + RTL.
- `jest.native.config.ts` — RN tests with `@testing-library/react-native`.
- `cypress.config.ts` + `cypress/e2e/basic.cy.ts` — E2E for web.
- `detox.config.js` + `e2e/firstTest.e2e.ts` — E2E for mobile.
- `.github/workflows/ci.yml` — CI matrix.

## TODOs and Why

1. **Web server command**  
   - Update CI Cypress step `start: npm run start` to your app's dev server.  
   - Why: Cypress needs a running server at `http://localhost:3000`.

2. **Next.js projects**  
   - If using Next.js, add `next`, `react`, `react-dom`, and consider `next/jest` for optimal config.  
   - Why: Next provides its own Jest helpers and build scripts.

3. **React Native app wiring**  
   - Provide a real RN project with `ios/` and `android/` folders, then fix `binaryPath` and `build` in `detox.config.js`.  
   - Why: Detox drives a compiled native app. Placeholders won't run.

4. **Babel for RN**  
   - Ensure `babel.config.js` is used by RN metro bundler.  
   - Why: RN needs the metro preset for tests and bundling.

5. **Index.html-only web**  
   - If serving a plain `index.html` via UMD React, replace Cypress `baseUrl` and server start command accordingly.  
   - Why: Current site is static HTML without a Node server.

6. **API call tests**  
   - Use `global.fetch = vi.fn()` (Vitest) or `jest.fn()` to mock `fetch`. Add sample tests near APIs.  
   - Why: Deterministic tests without real network I/O.

7. **Coverage thresholds** *(optional but recommended)*  
   - Add `coverageThreshold` in Jest configs and enable `--coverage` in CI.  
   - Why: Prevents regressions.

8. **Artifacts**  
   - If dashboards exist, add Cypress flows: signup, submit lead, view dashboard.  
   - Why: Aligns with Phase 3 user flows.

## Notes

- Web tests use Testing Library patterns: arrange, act, assert.
- RN tests use `@testing-library/react-native` queries and `jest-native` matchers.
- CI fails fast on lint or test errors as required.

