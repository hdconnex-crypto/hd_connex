
/* Supabase Edge Function: upsert_lead
 * Creates a lead with basic validation. Anonymous allowed.
 * Security: RLS on leads table still applies to reads. Inserts are open by policy.
 * TODO(anti-abuse): Verify CAPTCHA token before insert.
 */

import { serve } from "https://deno.land/std@0.193.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { requireString, requireEmail } from "../common/validation.ts";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY")!; // uses anon for public insert
  // TODO(security): For server-only operations use SERVICE_ROLE_KEY instead.

  const supabase = createClient(supabaseUrl, supabaseKey, { auth: { persistSession: false } });

  try {
    const payload = await req.json();
    const service = requireString(payload.service, "service");
    const county = requireString(payload.county, "county");
    const city = requireString(payload.city, "city");
    const details = requireString(payload.details ?? "", "details", 0, 4000);
    const contact_name = requireString(payload.name ?? payload.contact_name, "name");
    const contact_email = requireEmail(payload.email ?? payload.contact_email, "email");
    const contact_phone = String(payload.phone ?? "").slice(0, 32);
    const sms_opt_out = Boolean(payload.smsOptOut ?? payload.sms_opt_out ?? false);

    const { data, error } = await supabase
      .from("leads")
      .insert([{ service, county, city, details, contact_name, contact_email, contact_phone, sms_opt_out }])
      .select()
      .single();

    if (error) throw error;

    // TODO(notifications): Send webhook or email to internal inbox or contractor.
    return new Response(JSON.stringify({ ok: true, lead: data }), {
      headers: { "content-type": "application/json" },
    });
  } catch (e) {
    const msg = e?.message ?? "Bad Request";
    return new Response(JSON.stringify({ ok: false, error: msg }), { status: 400, headers: { "content-type": "application/json" } });
  }
});
