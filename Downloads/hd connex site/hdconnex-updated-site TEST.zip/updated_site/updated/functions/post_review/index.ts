
/* Supabase Edge Function: post_review
 * Auth required. Enforces RLS on insert.
 */

import { serve } from "https://deno.land/std@0.193.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { requireString, requireInt } from "../common/validation.ts";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  const authHeader = req.headers.get("Authorization") ?? "";
  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: authHeader } }, // forward user JWT so RLS applies
  });

  try {
    const { project_id, contractor_id, rating, content } = await req.json();
    if (!project_id || !contractor_id) throw new Error("project_id and contractor_id are required");
    const ratingInt = requireInt(rating, "rating", 1, 5);
    const reviewText = requireString(content, "content", 3, 4000);

    const { data, error } = await supabase
      .from("reviews")
      .insert([{ project_id, contractor_id, rating: ratingInt, content: reviewText }])
      .select()
      .single();

    if (error) throw error;

    return new Response(JSON.stringify({ ok: true, review: data }), { headers: { "content-type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ ok:false, error: e?.message ?? "Bad Request" }), { status: 400, headers: { "content-type":"application/json" } });
  }
});
