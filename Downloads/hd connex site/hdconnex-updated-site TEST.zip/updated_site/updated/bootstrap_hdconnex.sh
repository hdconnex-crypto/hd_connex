#!/usr/bin/env bash
set -euo pipefail

echo "HD Connex bootstrap starting..."

# Requirements check
command -v node >/dev/null 2>&1 || { echo "Node.js not found. Install Node >= 18.17"; exit 1; }
command -v npm  >/dev/null 2>&1 || { echo "npm not found. Install npm"; exit 1; }
node_ver=$(node -v | sed 's/v//')
echo "Node $(node -v) detected"

# Ensure repo root contains expected files
if [ ! -f "package.json" ] || [ ! -f "tsconfig.base.json" ]; then
  echo "This script expects to run at the monorepo root containing package.json and tsconfig.base.json."
  echo "Unzip hdconnex-starter.zip here first, then rerun."
  exit 1
fi

# Install root deps
echo "Installing root devDependencies..."
npm i

# Scaffold Next.js app if missing
if [ ! -d "apps/web" ] || [ -z "$(ls -A apps/web 2>/dev/null || true)" ]; then
  echo "Scaffolding Next.js app at apps/web ..."
  npx create-next-app@latest apps/web --ts --eslint --use-npm --src-dir --app --import-alias "@/*" --no-tailwind
else
  echo "apps/web already exists. Skipping scaffold."
fi

# Scaffold Expo app if missing
if [ ! -d "apps/mobile" ] || [ -z "$(ls -A apps/mobile 2>/dev/null || true)" ]; then
  echo "Scaffolding Expo app at apps/mobile ..."
  npx create-expo-app apps/mobile
else
  echo "apps/mobile already exists. Skipping scaffold."
fi

# Prisma setup
if [ -f "packages/db/prisma/schema.prisma" ]; then
  echo "Setting up Prisma..."
  if ! command -v npx >/dev/null 2>&1; then
    echo "npx not found. Install Node/npm properly." && exit 1
  fi
  npx prisma generate --schema packages/db/prisma/schema.prisma || true
  echo "NOTE: Set DATABASE_URL in your environment before using Prisma."
fi

# Git init if needed
if [ ! -d ".git" ]; then
  echo "Initializing git repository..."
  git init
  git add .
  git commit -m "chore: initial scaffold for HD Connex"
fi

echo "Running lint and typecheck..."
npm run lint || true
npm run typecheck || true

cat <<'EOF'

Bootstrap complete.

Next steps:
1) Configure secrets:
   - DATABASE_URL
   - STRIPE_SECRET_KEY and webhook signing secret
   - AUTH provider keys (Clerk/NextAuth/Auth0 etc.)
2) Decide realtime transport for messaging (Pusher/Ably/Socket/WebSocket server).
3) Choose scheduling/calendar integration and timezone rules.
4) Wire CI to your repo on GitHub (workflow is in .github/workflows/ci.yml).

Blocked items documented in docs/requirements.md remain until providers and policies are chosen.
EOF
