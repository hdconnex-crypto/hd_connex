# Apple App Store Submission Checklist

## Preflight
- [ ] Run full QA on real devices. No crashes. No debug menus.
- [ ] All account-required features accessible via **review/demo credentials**.
  - TODO: supply `username` and `password` for App Review.
- [ ] App icon and screenshots match current build features and UI.
- [ ] In‑app purchases configured and tested (if any). Provide steps in `Review Notes`.
- [ ] URLs valid: support, marketing, privacy policy.

## Guideline coverage (sections from Apple’s App Review Guidelines)
- Safety, Performance, Business, Design, Legal — verify each feature against these sections.
  - TODO: Map each feature → guideline numbers you verified.

## “Before You Submit” musts
- [ ] Test for crashes on cold launch and background/foreground transitions.
- [ ] Accurate metadata. No misleading claims or keyword stuffing.
- [ ] Provide complete access for App Review, including feature flags and geo-gated areas.
- [ ] Keep backends live during review. Provide test data if needed.
- [ ] Explain any non‑obvious flows, account creation, or paywalls in `Review Notes`.
  - TODO: Paste your Review Notes here.

## Privacy
- [ ] Privacy policy URL reachable, readable, and consistent with data collection.
- [ ] App Tracking Transparency (if tracking). Show ATT prompt only after context screen.
- [ ] Health/financial/children’s data handled per platform rules.
- [ ] Data types in App Store Connect match the actual collection in code.
  - TODO: List SDKs and analytics libraries.

## Export compliance
- [ ] If using encryption, complete export compliance questions in App Store Connect.

## Test accounts (example block for review notes)
```
Login: TODO_EMAIL
Password: TODO_PASSWORD
Special steps: e.g., tap “Demo Mode” on first screen to preload sample data.
```

References: Apple App Review Guidelines and TestFlight docs.
