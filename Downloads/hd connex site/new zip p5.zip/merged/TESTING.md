# Beta Testing

## iOS – TestFlight
1. Upload build to App Store Connect.
2. Add internal testers and assign builds.
3. For external testing, create a group, add testers, and submit the first build for beta review.
4. Builds expire after 90 days.

## Google Play – Internal Testing
1. Create an Internal test track.
2. Add testers via email list or Google Group.
3. Upload `.aab`, roll out to testers, review Pre‑launch report.

## Bug reporting
- Centralize feedback. Add in‑app "Send Feedback" or link to issue tracker.
- Crash reports: enable symbolication/dSYMs and ProGuard mappings uploads.
