
// Frontend: Supabase client setup exposing a global singleton.
// Load with: <script type="module" src="/js/supabaseClient.js"></script>
// Access from Babel/UMD code as: window.sbClient

// TODO(secrets): Replace placeholders with your project's values.
const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co"; // TODO
const SUPABASE_ANON_KEY = "YOUR-ANON-KEY"; // TODO

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

export const sbClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
window.sbClient = sbClient; // expose to global so existing inline scripts can use it
