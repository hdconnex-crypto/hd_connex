import { render, screen } from '@testing-library/react';
import React from 'react';

function Hero() {
  return <h1>Quality Contractors</h1>;
}

test('renders hero headline', () => {
  render(<Hero />);
  expect(screen.getByText(/Quality Contractors/i)).toBeInTheDocument();
});
