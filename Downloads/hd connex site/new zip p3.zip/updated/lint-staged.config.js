module.exports = {
  '**/*.{ts,tsx,js,jsx}': ['eslint --fix'],
  '**/*.{md,json,yml,yaml,css,scss,less}': ['prettier --write']
};
