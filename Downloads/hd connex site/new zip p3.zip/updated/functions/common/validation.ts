
/**
 * Shared validation helpers.
 * TODO(validation): replace with Zod if you prefer richer errors.
 */

export function requireString(value: unknown, field: string, min = 1, max = 2048) {
  if (typeof value !== 'string') throw new Error(`${field} must be a string`);
  const v = value.trim();
  if (v.length < min) throw new Error(`${field} is required`);
  if (v.length > max) throw new Error(`${field} too long`);
  return v;
}

export function optionalString(value: unknown, field: string, max = 2048) {
  if (value == null) return null;
  if (typeof value !== 'string') throw new Error(`${field} must be a string`);
  const v = value.trim();
  if (v.length > max) throw new Error(`${field} too long`);
  return v;
}

export function requireEmail(value: unknown, field = 'email') {
  const v = requireString(value, field, 3, 320);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new Error(`${field} invalid`);
  return v;
}

export function requireInt(value: unknown, field: string, min = 0, max = 1_000_000) {
  const n = Number(value);
  if (!Number.isInteger(n)) throw new Error(`${field} must be integer`);
  if (n < min || n > max) throw new Error(`${field} out of range`);
  return n;
}
