
/* Supabase Edge Function: search_contractors
 * Public search of approved contractors with filters.
 */

import { serve } from "https://deno.land/std@0.193.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { requireString, optionalString } from "../common/validation.ts";

serve(async (req) => {
  if (req.method !== "GET") return new Response("Method Not Allowed", { status: 405 });

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { auth: { persistSession: false } });

  const url = new URL(req.url);
  const service = optionalString(url.searchParams.get("service"), "service");
  const county = optionalString(url.searchParams.get("county"), "county");
  const q = optionalString(url.searchParams.get("q"), "q");

  let query = supabase.from("contractors").select("*").eq("status","approved");
  if (service) query = query.contains("specialties", [service]);
  if (county) query = query.contains("service_areas", [county]);
  if (q) query = query.ilike("company_name", `%${q}%`);

  const { data, error } = await query.limit(50);

  if (error) return new Response(JSON.stringify({ ok:false, error: error.message }), { status: 400 });

  return new Response(JSON.stringify({ ok:true, contractors: data }), { headers: { "content-type":"application/json" } });
});
