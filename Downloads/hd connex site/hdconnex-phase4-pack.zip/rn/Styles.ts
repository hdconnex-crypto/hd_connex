import { StyleSheet } from 'react-native';
export const spacing = 8;
export const colors = { primary:'#3b82f6', accent:'#f97316', bg:'#ffffff', text:'#111827' };
export const radii = { sm:8, md:12, lg:20 };
export const shadows = { card:{ shadowColor:'#000', shadowOpacity:.15, shadowRadius:12, shadowOffset:{width:0,height:6}, elevation:4 } };
export const ui = StyleSheet.create({
  container:{ flex:1, backgroundColor:colors.bg, padding:spacing*2 },
  h1:{ fontSize:28, fontWeight:'800', color:colors.text },
  paragraph:{ fontSize:16, lineHeight:22, color:'#374151' },
  button:{ paddingVertical:spacing*1.5, paddingHorizontal:spacing*2, borderRadius:radii.lg, alignItems:'center' },
  buttonPrimary:{ backgroundColor:colors.accent },
  input:{ borderWidth:2, borderColor:'#e5e7eb', padding:spacing*1.5, borderRadius:radii.md },
  inputInvalid:{ borderColor:'#dc2626' }
});