App Store review: supply demo credentials, ensure back-end live for review build, complete metadata and privacy, shipping icons and splash screens.
TODO: finalize branding assets and reviewer account.
