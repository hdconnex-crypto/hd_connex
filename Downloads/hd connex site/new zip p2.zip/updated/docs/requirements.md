# Requirements and Scope

## Roles
- **Homeowner**: submits projects, reviews contractors, messages, schedules.
- **Contractor**: signs up, manages profile, buys/leads or subscribes, messages, schedules, invoices.
- **Admin**: verifies contractors, moderates reviews, manages billing plans, resolves disputes, exports.

## Core Features (MVP)
1. **Lead capture**: multi-step form, geo + category, contact prefs, consent logging.
2. **Contractor sign‑up**: license + insurance attestation, service areas, specialties, verification queue.
3. **Dashboards**:
   - Homeowner: requests, quotes, messages, appointments.
   - Contractor: leads, pipeline, quotes, messages, subscription status.
   - Admin: applications, flags, payouts, refunds, audit logs.
4. **Admin tools**: approve/reject contractors, edit listings, export CSV, role management.
5. **Billing**: plans (subscription vs. commission), invoices, proration, dunning hooks.

## Optional Features (Phase 2)
- **Ratings/Reviews** with verification and fraud controls.
- **Messaging** with typing indicators and file attachments.
- **Job scheduling** with availability, iCal export, reminders.
- **Search + discovery** with county/city filters and tags.
- **Content CMS** for FAQs and landing pages.

## Technology Stack
- **Web**: Next.js 14+ with TypeScript.
- **Mobile**: React Native via Expo.
- **API**: Next.js Route Handlers or a dedicated service (Node), JSON over HTTPS, WebSocket for realtime.
- **DB**: PostgreSQL. ORM: Prisma.
- **Auth**: email + OTP or OAuth; role-based access control.
- **Payments**: Stripe (subscriptions + payment links) (pending real keys).
- **Infra**: Vercel for web, Expo EAS for mobile, Fly/Render for APIs if split. CDN for assets.

## Repositories
- **Monorepo** with npm workspaces: `apps/web`, `apps/mobile`, `packages/db`, `packages/ui` (optional).

## Data Models (first pass)
- **User**: base account, role flags.
- **ContractorProfile**: company data, license, insurance, service areas, rating cache.
- **Project**: homeowner request, status, location, category.
- **Review**: rating, text, verified flag.
- **Payment**: amount, currency, status, Stripe ids.
- **Subscription**: plan, status, current period.
- **Message**: conversation between homeowner and contractor.
- **JobSchedule**: appointment slots, confirmations.

## Scope limits now
- No third‑party keys included.
- Email/SMS providers not wired.
- Push notifications not wired.
- File uploads not wired.
- Fraud/abuse heuristics stub only.

## Notation of what remains and why
- **Auth + RBAC**: blocked on provider choice and policy rules.
- **Stripe integration**: blocked on live keys and webhook endpoints.
- **Messaging realtime**: blocked on transport (Pusher/Socket/WS) decision.
- **Scheduling**: requires calendar provider selection and time zone rules.
- **Review verification**: needs proof-of-workflow and moderation policy.
- **DevOps**: domains, secrets, and environments pending.
