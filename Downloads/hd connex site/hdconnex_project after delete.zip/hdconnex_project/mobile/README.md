# HD Connex Mobile (Expo/React Native)

This folder contains a basic **React Native / Expo** skeleton for the HD Connex mobile application.  It mirrors the structure of the web version with separate screens and reusable components.

## Prerequisites

Install the [Expo CLI](https://docs.expo.dev/get-started/installation/) globally:

```bash
npm install --global expo-cli
```

## How to use

1. Install dependencies:

```bash
cd mobile
npm install
```

2. Start the Expo development server:

```bash
npm start
```

3. Use the Expo Go app on your iOS or Android device to scan the QR code and view the app.

## Structure

- **App.tsx** – Configures navigation using React Navigation.  It registers each screen: Home, SignUp, ContractorDashboard, ContractorProfile, AdminDashboard and Billing.
- **components/** – Reusable UI components for the hero section, lead capture form, contractor value proposition cards, reviews and sign-up form.
- **screens/** – Individual screens that wrap components for a complete page.  These screens correspond to the same features found in the web application.

## Notes

- The mobile skeleton uses React Navigation for stack navigation.  You will need to install additional native modules if you eject from Expo.
- API calls and state management are not included here; each form currently logs data or displays alerts.  Integrate with your backend and adopt a state management solution (Context, Redux, etc.) as needed.
- To comply with App Store and Google Play guidelines, ensure you add a privacy policy, accessibility support and high‑resolution app icons.  Use the `app.json` file to configure your splash screens, icons and permissions before publishing.