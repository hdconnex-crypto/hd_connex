import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './screens/HomeScreen';
import SignUpScreen from './screens/SignUpScreen';
import ContractorDashboardScreen from './screens/ContractorDashboardScreen';
import ContractorProfileScreen from './screens/ContractorProfileScreen';
import AdminDashboardScreen from './screens/AdminDashboardScreen';
import BillingScreen from './screens/BillingScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} options={{ title: 'Sign Up' }} />
        <Stack.Screen name="ContractorDashboard" component={ContractorDashboardScreen} options={{ title: 'Dashboard' }} />
        <Stack.Screen name="ContractorProfile" component={ContractorProfileScreen} options={{ title: 'Profile' }} />
        <Stack.Screen name="AdminDashboard" component={AdminDashboardScreen} options={{ title: 'Admin' }} />
        <Stack.Screen name="Billing" component={BillingScreen} options={{ title: 'Billing' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}