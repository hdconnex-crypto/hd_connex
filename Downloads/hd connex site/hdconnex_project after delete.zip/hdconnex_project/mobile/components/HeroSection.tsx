import { View, Text, Button, StyleSheet } from 'react-native';

export default function HeroSection({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Connecting You to Quality</Text>
      <Text style={styles.subtitle}>We make it easy to find top-rated contractors for your project.</Text>
      <Button title="Get Started" onPress={onGetStarted} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    backgroundColor: '#3b82f6',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 12,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#e0e0e0',
    marginBottom: 20,
    textAlign: 'center',
  },
});