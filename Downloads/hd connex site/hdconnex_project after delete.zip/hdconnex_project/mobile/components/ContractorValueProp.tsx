import { View, Text, StyleSheet } from 'react-native';

const features = [
  { title: 'Verified Contractors', description: 'We thoroughly vet every contractor to ensure they meet our standards.' },
  { title: 'Transparent Bidding', description: 'Receive fair, competitive bids from multiple contractors.' },
  { title: 'Dedicated Support', description: 'Our customer support team is here to help every step of the way.' },
];

export default function ContractorValueProp() {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Why Choose HD Connex?</Text>
      {features.map(feature => (
        <View key={feature.title} style={styles.card}>
          <Text style={styles.cardTitle}>{feature.title}</Text>
          <Text style={styles.cardDesc}>{feature.description}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#f5f5f5' },
  heading: { fontSize: 24, fontWeight: 'bold', marginBottom: 12 },
  card: { marginBottom: 12, padding: 12, backgroundColor: '#fff', borderRadius: 8, elevation: 1 },
  cardTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  cardDesc: { fontSize: 14, color: '#666' },
});