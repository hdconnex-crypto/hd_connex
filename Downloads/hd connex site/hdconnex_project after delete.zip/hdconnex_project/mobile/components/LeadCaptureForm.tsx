import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { useState } from 'react';

export interface LeadData {
  name: string;
  email: string;
  phone?: string;
  description: string;
}

export default function LeadCaptureForm({ onSubmit }: { onSubmit: (data: LeadData) => void }) {
  const [formData, setFormData] = useState<LeadData>({ name: '', email: '', phone: '', description: '' });

  const handleChange = (name: keyof LeadData, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onSubmit(formData);
    setFormData({ name: '', email: '', phone: '', description: '' });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Name</Text>
      <TextInput
        style={styles.input}
        value={formData.name}
        onChangeText={text => handleChange('name', text)}
      />
      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        value={formData.email}
        onChangeText={text => handleChange('email', text)}
        keyboardType="email-address"
      />
      <Text style={styles.label}>Phone (optional)</Text>
      <TextInput
        style={styles.input}
        value={formData.phone}
        onChangeText={text => handleChange('phone', text)}
        keyboardType="phone-pad"
      />
      <Text style={styles.label}>Project Description</Text>
      <TextInput
        style={[styles.input, { height: 80 }]}
        value={formData.description}
        onChangeText={text => handleChange('description', text)}
        multiline
      />
      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontWeight: '500',
    marginBottom: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 8,
    marginBottom: 12,
  },
});