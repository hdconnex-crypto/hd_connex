import { View, Text, StyleSheet } from 'react-native';

const reviews = [
  { name: 'Jane D.', rating: 5, text: 'HD Connex made it easy to find a reliable contractor for my home renovation.' },
  { name: 'Carlos M.', rating: 4, text: 'The bidding process was transparent and I got multiple quotes quickly.' },
  { name: 'Sarah K.', rating: 5, text: 'Great experience from start to finish. Highly recommended!' },
];

export default function ReviewsSection() {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>What Our Customers Say</Text>
      {reviews.map((review, index) => (
        <View key={index} style={styles.card}>
          <Text style={styles.stars}>{'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}</Text>
          <Text style={styles.author}>{review.name}</Text>
          <Text style={styles.text}>{review.text}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  heading: { fontSize: 24, fontWeight: 'bold', marginBottom: 12 },
  card: { marginBottom: 12, padding: 12, borderWidth: 1, borderColor: '#ddd', borderRadius: 8 },
  stars: { fontSize: 18, color: '#fbbf24', marginBottom: 4 },
  author: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  text: { fontSize: 14, color: '#444' },
});