import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { useState } from 'react';

export interface ContractorData {
  name: string;
  email: string;
  phone: string;
  trade: string;
  experience: string;
  description: string;
}

export default function ContractorSignUpForm({ onSubmit }: { onSubmit: (data: ContractorData) => void }) {
  const [formData, setFormData] = useState<ContractorData>({
    name: '',
    email: '',
    phone: '',
    trade: '',
    experience: '',
    description: '',
  });

  const handleChange = (key: keyof ContractorData, value: string) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = () => {
    onSubmit(formData);
    setFormData({ name: '', email: '', phone: '', trade: '', experience: '', description: '' });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Join HD Connex</Text>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={formData.name}
        onChangeText={text => handleChange('name', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={formData.email}
        onChangeText={text => handleChange('email', text)}
        keyboardType="email-address"
      />
      <TextInput
        style={styles.input}
        placeholder="Phone"
        value={formData.phone}
        onChangeText={text => handleChange('phone', text)}
        keyboardType="phone-pad"
      />
      <TextInput
        style={styles.input}
        placeholder="Trade"
        value={formData.trade}
        onChangeText={text => handleChange('trade', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Experience (years)"
        value={formData.experience}
        onChangeText={text => handleChange('experience', text)}
        keyboardType="numeric"
      />
      <TextInput
        style={[styles.input, { height: 80 }]}
        placeholder="About You"
        value={formData.description}
        onChangeText={text => handleChange('description', text)}
        multiline
      />
      <Button title="Sign Up" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  heading: { fontSize: 24, fontWeight: 'bold', marginBottom: 12 },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 6, padding: 8, marginBottom: 12 },
});