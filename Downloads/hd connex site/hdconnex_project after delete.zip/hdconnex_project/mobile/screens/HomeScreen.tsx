import { ScrollView, View, Text } from 'react-native';
import HeroSection from '../components/HeroSection';
import LeadCaptureForm from '../components/LeadCaptureForm';
import ContractorValueProp from '../components/ContractorValueProp';
import ReviewsSection from '../components/ReviewsSection';

export default function HomeScreen({ navigation }: { navigation: any }) {
  return (
    <ScrollView>
      <HeroSection onGetStarted={() => navigation.navigate('SignUp')} />
      <View style={{ padding: 16 }}>
        <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 16 }}>Tell Us About Your Project</Text>
        <LeadCaptureForm onSubmit={(data) => console.log('Lead submitted:', data)} />
      </View>
      <ContractorValueProp />
      <ReviewsSection />
    </ScrollView>
  );
}