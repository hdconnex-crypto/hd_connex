import { View, Text } from 'react-native';

export default function BillingScreen() {
  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 12 }}>Billing</Text>
      <Text>Your billing information will appear here.</Text>
    </View>
  );
}