import { ScrollView, View, Text } from 'react-native';

const leads = [
  { id: 1, name: 'John Smith', email: 'john@example.com', description: 'Kitchen remodel' },
  { id: 2, name: 'Jane Doe', email: 'jane@example.com', description: 'Bathroom renovation' },
];

export default function ContractorDashboardScreen() {
  return (
    <ScrollView style={{ padding: 16 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 12 }}>My Leads</Text>
      {leads.map(lead => (
        <View key={lead.id} style={{ marginBottom: 12, padding: 12, borderWidth: 1, borderColor: '#ddd', borderRadius: 8 }}>
          <Text style={{ fontWeight: '600' }}>{lead.name}</Text>
          <Text>{lead.email}</Text>
          <Text style={{ color: '#666' }}>{lead.description}</Text>
        </View>
      ))}
    </ScrollView>
  );
}