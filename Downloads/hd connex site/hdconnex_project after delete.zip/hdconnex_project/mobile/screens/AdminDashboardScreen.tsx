import { ScrollView, View, Text } from 'react-native';

const leads = [
  { id: 1, name: 'John Smith', email: 'john@example.com', description: 'Kitchen remodel' },
  { id: 2, name: 'Jane Doe', email: 'jane@example.com', description: 'Bathroom renovation' },
];

const contractors = [
  { id: 1, name: 'ABC Plumbing', trade: 'Plumbing' },
  { id: 2, name: 'XYZ Construction', trade: 'Construction' },
];

export default function AdminDashboardScreen() {
  return (
    <ScrollView style={{ padding: 16 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 12 }}>Admin Dashboard</Text>
      <Text style={{ fontSize: 20, fontWeight: '600', marginTop: 16, marginBottom: 8 }}>Leads</Text>
      {leads.map(lead => (
        <View key={lead.id} style={{ marginBottom: 8, padding: 8, borderWidth: 1, borderColor: '#ddd', borderRadius: 8 }}>
          <Text style={{ fontWeight: '600' }}>{lead.name}</Text>
          <Text>{lead.email}</Text>
          <Text style={{ color: '#666' }}>{lead.description}</Text>
        </View>
      ))}
      <Text style={{ fontSize: 20, fontWeight: '600', marginTop: 16, marginBottom: 8 }}>Contractors</Text>
      {contractors.map(contractor => (
        <View key={contractor.id} style={{ marginBottom: 8, padding: 8, borderWidth: 1, borderColor: '#ddd', borderRadius: 8 }}>
          <Text style={{ fontWeight: '600' }}>{contractor.name}</Text>
          <Text style={{ color: '#666' }}>{contractor.trade}</Text>
        </View>
      ))}
    </ScrollView>
  );
}