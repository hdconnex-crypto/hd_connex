import { View, Text } from 'react-native';

const contractor = {
  id: 1,
  name: 'ABC Plumbing',
  trade: 'Plumbing',
  experience: 10,
  description: 'We offer reliable plumbing services for residential and commercial clients.',
};

export default function ContractorProfileScreen() {
  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontSize: 28, fontWeight: 'bold', marginBottom: 8 }}>{contractor.name}</Text>
      <Text style={{ fontSize: 16, color: '#555', marginBottom: 8 }}>
        {contractor.trade} · {contractor.experience} years of experience
      </Text>
      <Text>{contractor.description}</Text>
    </View>
  );
}