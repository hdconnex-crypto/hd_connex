import { ScrollView, Alert } from 'react-native';
import ContractorSignUpForm, { ContractorData } from '../components/ContractorSignUpForm';

export default function SignUpScreen({ navigation }: { navigation: any }) {
  const handleSignUp = (data: ContractorData) => {
    console.log('Contractor sign up:', data);
    Alert.alert('Thank you', 'Your application has been submitted.');
    navigation.navigate('ContractorDashboard');
  };

  return (
    <ScrollView>
      <ContractorSignUpForm onSubmit={handleSignUp} />
    </ScrollView>
  );
}