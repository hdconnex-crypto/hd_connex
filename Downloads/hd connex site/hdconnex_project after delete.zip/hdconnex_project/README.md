# HD Connex Project

This repository contains two separate codebases for the HD Connex application:

1. **Web** – a Next.js + TypeScript implementation (`web/`)
2. **Mobile** – a React Native + Expo implementation (`mobile/`)

Both projects are intended as starting points and require further development (authentication, backend integration, design polish, etc.) before production use.

Refer to the individual READMEs in each subdirectory for setup instructions.