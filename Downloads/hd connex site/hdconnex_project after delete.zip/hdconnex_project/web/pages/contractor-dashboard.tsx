import ContractorDashboard from '../components/ContractorDashboard';

const sampleLeads = [
  { id: 1, name: 'John Smith', email: 'john@example.com', description: 'Kitchen remodel' },
  { id: 2, name: 'Jane Doe', email: 'jane@example.com', description: 'Bathroom renovation' },
];

export default function ContractorDashboardPage() {
  return <ContractorDashboard leads={sampleLeads} />;
}