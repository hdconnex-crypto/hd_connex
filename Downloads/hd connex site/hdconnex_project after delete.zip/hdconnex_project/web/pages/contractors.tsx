import { useState } from 'react';
import ContractorSignUpForm, { ContractorData } from '../components/ContractorSignUpForm';
import Footer from '../components/Footer';
import { useRouter } from 'next/router';

export default function Contractors() {
  const [submitted, setSubmitted] = useState(false);
  const router = useRouter();

  const handleSignUp = async (data: ContractorData) => {
    try {
      const res = await fetch('/api/contractor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        setSubmitted(true);
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (submitted) {
    return (
      <div className="py-20 text-center">
        <h1 className="text-3xl font-bold mb-4">Thank you for signing up!</h1>
        <p className="mb-4">We’ll review your application and get back to you soon.</p>
        <button
          onClick={() => router.push('/contractor-dashboard')}
          className="bg-blue-600 text-white px-4 py-2 rounded-md"
        >
          Go to Dashboard
        </button>
      </div>
    );
  }

  return (
    <>
      <section className="py-12">
        <div className="container mx-auto px-4">
          <ContractorSignUpForm onSubmit={handleSignUp} />
        </div>
      </section>
      <Footer />
    </>
  );
}