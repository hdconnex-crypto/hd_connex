import { useRouter } from 'next/router';
import HeroSection from '../components/HeroSection';
import LeadCaptureForm, { LeadData } from '../components/LeadCaptureForm';
import ContractorValueProp from '../components/ContractorValueProp';
import ReviewsSection from '../components/ReviewsSection';
import Footer from '../components/Footer';

export default function Home() {
  const router = useRouter();

  const handleGetStarted = () => {
    router.push('/contractors');
  };

  const handleLeadSubmit = async (data: LeadData) => {
    try {
      const res = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        alert('Your request has been submitted!');
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <HeroSection onGetStarted={handleGetStarted} />
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Tell Us About Your Project</h2>
          <LeadCaptureForm onSubmit={handleLeadSubmit} />
        </div>
      </section>
      <ContractorValueProp />
      <ReviewsSection />
      <Footer />
    </>
  );
}