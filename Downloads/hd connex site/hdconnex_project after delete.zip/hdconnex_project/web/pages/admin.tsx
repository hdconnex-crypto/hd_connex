import AdminDashboard from '../components/AdminDashboard';

const sampleLeads = [
  { id: 1, name: 'John Smith', email: 'john@example.com', description: 'Kitchen remodel' },
  { id: 2, name: 'Jane Doe', email: 'jane@example.com', description: 'Bathroom renovation' },
];

const sampleContractors = [
  { id: 1, name: 'ABC Plumbing', trade: 'Plumbing' },
  { id: 2, name: 'XYZ Construction', trade: 'Construction' },
];

export default function Admin() {
  return <AdminDashboard leads={sampleLeads} contractors={sampleContractors} />;
}