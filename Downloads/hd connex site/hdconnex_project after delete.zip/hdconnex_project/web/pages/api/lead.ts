import type { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { name, email, phone, description } = req.body;
    // In a real application, you'd save this data to a database or CRM system.
    // For now, we'll just log the lead to the console and return a success response.
    console.log('New lead received:', { name, email, phone, description });
    return res.status(200).json({ message: 'Lead received' });
  }
  return res.status(405).end();
}