import type { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { name, email, phone, trade, experience, description } = req.body;
    // In a real application, you'd save this data to a database for vetting.
    console.log('New contractor application:', { name, email, phone, trade, experience, description });
    return res.status(200).json({ message: 'Application received' });
  }
  return res.status(405).end();
}