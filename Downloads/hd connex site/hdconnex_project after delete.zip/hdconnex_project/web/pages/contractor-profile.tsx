import ContractorProfile from '../components/ContractorProfile';

const exampleContractor = {
  id: 1,
  name: 'ABC Plumbing',
  trade: 'Plumbing',
  experience: 10,
  description: 'We offer reliable plumbing services for residential and commercial clients.',
};

export default function ContractorProfilePage() {
  return <ContractorProfile contractor={exampleContractor} />;
}