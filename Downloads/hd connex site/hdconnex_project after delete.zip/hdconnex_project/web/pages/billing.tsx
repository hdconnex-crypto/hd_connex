import BillingPage from '../components/BillingPage';

export default function Billing() {
  return <BillingPage />;
}