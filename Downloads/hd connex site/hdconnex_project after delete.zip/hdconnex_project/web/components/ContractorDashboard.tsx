interface Lead {
  id: number;
  name: string;
  email: string;
  description: string;
}

interface ContractorDashboardProps {
  leads: Lead[];
}

export default function ContractorDashboard({ leads }: ContractorDashboardProps) {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">My Leads</h2>
      <ul className="space-y-2">
        {leads.map(lead => (
          <li key={lead.id} className="border rounded-md p-2">
            <p className="font-bold">{lead.name}</p>
            <p>{lead.email}</p>
            <p className="text-gray-600">{lead.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}