import { useState } from 'react';

export interface ContractorData {
  name: string;
  email: string;
  phone: string;
  trade: string;
  experience: number;
  description: string;
}

interface ContractorSignUpFormProps {
  onSubmit: (data: ContractorData) => void;
}

export default function ContractorSignUpForm({ onSubmit }: ContractorSignUpFormProps) {
  const [formData, setFormData] = useState<ContractorData>({
    name: '',
    email: '',
    phone: '',
    trade: '',
    experience: 0,
    description: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'experience' ? Number(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData({ name: '', email: '', phone: '', trade: '', experience: 0, description: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-6 space-y-4 max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Join HD Connex</h2>
      <div>
        <label className="block font-medium">Name</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="w-full border rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block font-medium">Email</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          className="w-full border rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block font-medium">Phone</label>
        <input
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          className="w-full border rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block font-medium">Trade</label>
        <input
          type="text"
          name="trade"
          value={formData.trade}
          onChange={handleChange}
          className="w-full border rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block font-medium">Years of Experience</label>
        <input
          type="number"
          name="experience"
          value={formData.experience}
          onChange={handleChange}
          className="w-full border rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block font-medium">About You</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          className="w-full border rounded-md p-2"
          rows={3}
          required
        ></textarea>
      </div>
      <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">
        Sign Up
      </button>
    </form>
  );
}