interface ContractorProfileProps {
  contractor: {
    id: number;
    name: string;
    trade: string;
    experience: number;
    description: string;
  };
}

export default function ContractorProfile({ contractor }: ContractorProfileProps) {
  return (
    <div className="max-w-2xl mx-auto p-4">
      <h2 className="text-3xl font-bold mb-2">{contractor.name}</h2>
      <p className="text-gray-600 mb-4">
        {contractor.trade} · {contractor.experience} years
      </p>
      <p>{contractor.description}</p>
    </div>
  );
}