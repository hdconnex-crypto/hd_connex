export default function ContractorValueProp() {
  const features = [
    {
      title: 'Verified Contractors',
      description: 'We thoroughly vet every contractor to ensure they meet our standards.',
      icon: 'fa-user-check',
    },
    {
      title: 'Transparent Bidding',
      description: 'Receive fair, competitive bids from multiple contractors.',
      icon: 'fa-handshake',
    },
    {
      title: 'Dedicated Support',
      description: 'Our customer support team is here to help every step of the way.',
      icon: 'fa-headset',
    },
  ];

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">Why Choose HD Connex?</h2>
        <div className="grid gap-8 md:grid-cols-3">
          {features.map(feature => (
            <div key={feature.title} className="bg-white rounded-lg shadow p-6 text-center">
              <div className="text-4xl text-blue-600 mb-4">
                <i className={`fas ${feature.icon}`}></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}