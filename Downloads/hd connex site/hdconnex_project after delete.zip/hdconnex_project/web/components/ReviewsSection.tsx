interface Review {
  name: string;
  rating: number;
  text: string;
}

const reviews: Review[] = [
  { name: 'Jane D.', rating: 5, text: 'HD Connex made it easy to find a reliable contractor for my home renovation.' },
  { name: 'Carlos M.', rating: 4, text: 'The bidding process was transparent and I got multiple quotes quickly.' },
  { name: 'Sarah K.', rating: 5, text: 'Great experience from start to finish. Highly recommended!' },
];

export default function ReviewsSection() {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">What Our Customers Say</h2>
        <div className="space-y-6 md:space-y-0 md:grid md:grid-cols-3 md:gap-6">
          {reviews.map((review, index) => (
            <div key={index} className="border rounded-lg p-6">
              <div className="flex items-center mb-4">
                <div className="text-2xl text-yellow-400 mr-2">
                  {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}
                </div>
                <span className="font-semibold">{review.name}</span>
              </div>
                <p className="text-gray-700">{review.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}