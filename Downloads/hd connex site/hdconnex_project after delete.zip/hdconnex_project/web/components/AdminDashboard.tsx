interface Lead {
  id: number;
  name: string;
  email: string;
  description: string;
}

interface Contractor {
  id: number;
  name: string;
  trade: string;
}

interface AdminDashboardProps {
  leads: Lead[];
  contractors: Contractor[];
}

export default function AdminDashboard({ leads, contractors }: AdminDashboardProps) {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Admin Dashboard</h2>
      <div className="mb-8">
        <h3 className="text-xl font-semibold mb-2">Leads</h3>
        <ul className="space-y-2">
          {leads.map(lead => (
            <li key={lead.id} className="border rounded-md p-2">
              <p className="font-bold">{lead.name}</p>
              <p>{lead.email}</p>
              <p className="text-gray-600">{lead.description}</p>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h3 className="text-xl font-semibold mb-2">Contractors</h3>
        <ul className="space-y-2">
          {contractors.map(contractor => (
            <li key={contractor.id} className="border rounded-md p-2">
              <p className="font-bold">{contractor.name}</p>
              <p className="text-gray-600">{contractor.trade}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}