export default function BillingPage() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Billing</h2>
      <p>Billing and subscription information will appear here.</p>
    </div>
  );
}