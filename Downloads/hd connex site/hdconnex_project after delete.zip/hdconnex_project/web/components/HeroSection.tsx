interface HeroSectionProps {
  onGetStarted: () => void;
}

export default function HeroSection({ onGetStarted }: HeroSectionProps) {
  return (
    <section className="gradient-bg text-white py-20">
      <div className="container mx-auto text-center px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Connecting You to Quality</h1>
        <p className="text-lg md:text-xl mb-8">We make it easy to find top-rated contractors for your project.</p>
        <button
          onClick={onGetStarted}
          className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold transition duration-300 hover:bg-blue-100"
        >
          Get Started
        </button>
      </div>
    </section>
  );
}