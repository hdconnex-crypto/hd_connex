# HD Connex Web

This folder contains a basic **Next.js + TypeScript** skeleton for the HD Connex web application.  It breaks the original single‑page demo into reusable React components and pages, and adds minimal API routes to illustrate how form submissions could be handled.

## How to use

1. Install dependencies:

```bash
npm install
```

2. Start the development server:

```bash
npm run dev
```

3. Open your browser to `http://localhost:3000` to see the application.

## Structure

- **pages/** – Next.js pages.  `index.tsx` is the landing page, `contractors.tsx` handles contractor signup, `contractor-dashboard.tsx`, `admin.tsx` and `billing.tsx` are simple dashboard pages.  `pages/api/*` provide basic API examples for leads and contractor applications.
- **components/** – Reusable UI components such as the hero section, lead capture form, contractor signup form, value proposition cards, reviews section and dashboards.
- **styles/** – Global Tailwind CSS import and a custom gradient class.
- **public/** – Static assets.  A placeholder image is provided; replace it with your own logo.

## Notes

- The API routes (`pages/api/lead.ts` and `pages/api/contractor.ts`) simply log form data to the server console.  Replace these with real database calls.
- Tailwind CSS is included but not configured with PostCSS here.  To enable full Tailwind support, install Tailwind and create a `tailwind.config.js` according to the [Tailwind docs](https://tailwindcss.com/docs/guides/nextjs).
- This skeleton focuses on structure and type safety.  Add authentication, database integration and state management (e.g. Context or Redux) as your project grows.