# Phase 5 – Store Submission Pack
Generated: 2025-08-27

Use this pack to finish App Store and Google Play submission. Every file contains TODOs that you must replace before publishing.

Contents:
- CHECKLIST_APPLE.md
- CHECKLIST_GOOGLE.md
- PRIVACY_POLICY_TEMPLATE.md
- DATA_SAFETY_FORM_GUIDE.md
- PERMISSIONS_DECLARATIONS.md
- STORE_ASSETS/ (asset specs + placeholders)
- METADATA/appstore/metadata.json
- METADATA/playstore/listing.txt
- CERTS_AND_IDS.md
- BUILD_GUIDE.md
- TESTING.md
