# Production Builds

## Web (Next.js)
1. Set `NODE_ENV=production`.
2. Run `next build` then `next start` or deploy to Vercel/Netlify.
3. Remove debug flags and ensure env vars are production-safe.

## iOS
- With Xcode:
  1. Select `Any iOS Device (arm64)`.
  2. Product → Archive. Validate and upload to App Store Connect.
- With EAS (Expo):
  1. `eas build -p ios --profile production`
  2. Ensure `bundleIdentifier` and `entitlements` are set.

## Android
- Gradle:
  1. Set `compileSdkVersion 35` and `targetSdkVersion 35`. **TODO confirm.**
  2. `./gradlew assembleRelease` → produces `.aab`.
- Expo EAS:
  - `eas build -p android --profile production`

## Verification
- Open generated artifacts on devices via TestFlight and Internal Testing before public release.
- Confirm that the shipped build number matches store metadata.
