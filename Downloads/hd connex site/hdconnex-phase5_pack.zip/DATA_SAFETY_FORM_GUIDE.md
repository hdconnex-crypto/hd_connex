# Data Safety and App Store Privacy Labels Guide

Map each data type to collection, purpose, and sharing.

## Inventory
- Analytics SDKs: TODO list with versions.
- Crash reporting: TODO tool.
- Ads SDKs: TODO or N/A.
- Feature SDKs (maps, payments, auth): TODO.

## Apple labels mapping
- Collected: Contact info (email, phone) — Purposes: App functionality, Support.
- Not linked to user: Usage data for analytics (if de‑identified).
- Tracking: Set to **No** unless cross‑app tracking occurs.

## Google Play Data Safety
For each category declare:
- Collected: Yes/No
- Shared: Yes/No
- Purpose: App functionality, Analytics, Fraud prevention, etc.
- Data handling: optional, required, user choice.

## Verification
- Run a static review of code for trackers/permissions.
- Compare declarations with actual runtime network calls.
- Keep screenshots/export of submissions for audit.
