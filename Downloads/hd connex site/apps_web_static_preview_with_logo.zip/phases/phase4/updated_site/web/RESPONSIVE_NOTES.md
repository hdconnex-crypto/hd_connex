
Use these Tailwind patterns in your JSX:
- Layout grid: `grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6`
- Container: `container mx-auto px-4 sm:px-6 lg:px-8`
- Type scale: `text-xl sm:text-2xl md:text-3xl`
- Images: `w-full h-auto object-cover rounded-xl`
- Buttons: `px-6 py-3 text-base sm:text-lg`
