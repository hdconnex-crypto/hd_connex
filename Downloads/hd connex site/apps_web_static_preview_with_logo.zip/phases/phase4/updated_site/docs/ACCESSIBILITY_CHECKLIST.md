- Skip link included
- Focus-visible styles
- Reduced motion respected
- Dialog semantics scaffolded
- Forms expose aria-invalid and role=alert
TODO: wire per-field validation messages, verify color contrast with final palette, run SR smoke tests.
