# Privacy Policy for HD Connex
**Effective date:** TODO_DATE

HD Connex (“we”, “us”, “our”) operates the HD Connex application and website.

## Data We Collect
- Account data: name, email, phone. **Purpose:** account and support.
- Usage data: app interactions, device info. **Purpose:** performance and analytics.
- Location data: **TODO whether collected.** Purpose must be explicit or remove.
- Payment data: processed by **TODO provider**; we do not store full card numbers.

## How We Use Data
- Provide and improve services.
- Customer support and safety.
- Marketing with consent where required. **TODO confirm marketing behavior.**

## Sharing
- Service providers (hosting, analytics, crash reporting).
- Legal compliance. No sale of personal data.

## Retention
- Keep personal data only as long as needed for the stated purposes.

## User Rights
- Access, correction, deletion, portability. Contact: **support@TODO**.

## Children
- Not intended for users under **TODO age**. Remove or adapt if COPPA applies.

## Security
- Transit encryption (TLS). At rest: **TODO**.

## International Transfers
- If applicable, describe safeguards (SCCs/UK IDTA). **TODO**.

## Contact
- Company legal name
- Address
- Email: **privacy@TODO**

This policy must match real app behavior and store declarations.
