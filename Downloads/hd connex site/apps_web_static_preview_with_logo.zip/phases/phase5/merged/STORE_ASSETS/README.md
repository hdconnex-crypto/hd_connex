# Store Assets Specifications

## iOS
- App Icon: 1024×1024 PNG, no transparency.
- Screenshots:
  - 6.7", 6.5", 5.5" iPhone sizes required; iPad sizes strongly recommended.
  - Use the exact device pixel sizes from Apple docs.
- Optional: App Preview video (15–30 s).

## Android
- App Icon: 512×512 PNG.
- Feature Graphic: 1024×500 PNG/JPG.
- Screenshots: phone and 7‑inch/10‑inch tablet. Min 2 per class, 8 recommended.
- Promo video optional via YouTube link.

## Web (marketing)
- Store description, promo text, keywords kept in `METADATA/*` below.

**TODO:** Export fresh screenshots from the current build and place here.
