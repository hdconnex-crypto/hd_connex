# Permissions and Disclosures

## iOS
- Push Notifications: prompt after context screen. Link to settings.
- Location: If needed, include `NSLocationWhenInUseUsageDescription` with human text.
- Photos/Camera/Microphone: Explain feature in pre‑prompt screen.

## Android (example `AndroidManifest.xml` entries)
```xml
<!-- TODO: Remove unused permissions -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<!-- If location: -->
<!-- <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" /> -->
```

### Runtime disclosures
Show an inline rationale before requesting any sensitive permission. Provide an opt‑out path.
