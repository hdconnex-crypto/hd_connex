
-- Row Level Security policies
alter table public.profiles enable row level security;
alter table public.contractors enable row level security;
alter table public.leads enable row level security;
alter table public.projects enable row level security;
alter table public.reviews enable row level security;

-- PROFILES
drop policy if exists profiles_self_select on public.profiles;
create policy profiles_self_select on public.profiles
for select using (auth.uid() = auth_user_id or auth.role() = 'anon'); -- allow public read of profiles with anonymized fields if desired
-- TODO(privacy): If profiles contain PII later, tighten this to auth.uid() = auth_user_id or admin.

drop policy if exists profiles_self_upsert on public.profiles;
create policy profiles_self_upsert on public.profiles
for all using (auth.uid() = auth_user_id) with check (auth.uid() = auth_user_id);

-- CONTRACTORS
drop policy if exists contractors_public_read on public.contractors;
create policy contractors_public_read on public.contractors
for select using (status = 'approved'); -- public can read only approved contractors

drop policy if exists contractors_owner_upsert on public.contractors;
create policy contractors_owner_upsert on public.contractors
for all using (owner_auth_user_id = auth.uid())
with check (owner_auth_user_id = auth.uid());

-- Admin override via service role only.
-- TODO(security): use Postgres roles or a claim in JWT to grant admin access when needed.

-- LEADS
drop policy if exists leads_owner_read on public.leads;
create policy leads_owner_read on public.leads
for select using (homeowner_auth_user_id = auth.uid() or auth.uid() in (select owner_auth_user_id from public.contractors where id = leads.assigned_contractor_id));

drop policy if exists leads_insert_anyone on public.leads;
create policy leads_insert_anyone on public.leads
for insert with check (true); -- allows anon lead creation
-- TODO(anti-abuse): put API gateway or Cloudflare Turnstile before this endpoint in production.

drop policy if exists leads_owner_update on public.leads;
create policy leads_owner_update on public.leads
for update using (homeowner_auth_user_id = auth.uid());

-- PROJECTS
drop policy if exists projects_visible_to_parties on public.projects;
create policy projects_visible_to_parties on public.projects
for select using (auth.uid() = homeowner_auth_user_id or auth.uid() in (select owner_auth_user_id from public.contractors where contractors.id = projects.contractor_id));

drop policy if exists projects_parties_update on public.projects;
create policy projects_parties_update on public.projects
for update using (auth.uid() = homeowner_auth_user_id or auth.uid() in (select owner_auth_user_id from public.contractors where contractors.id = projects.contractor_id));

-- REVIEWS
drop policy if exists reviews_public_read on public.reviews;
create policy reviews_public_read on public.reviews
for select using (true);

drop policy if exists reviews_homeowner_insert on public.reviews;
create policy reviews_homeowner_insert on public.reviews
for insert with check (
  auth.uid() = homeowner_auth_user_id
  and exists (
    select 1 from public.projects p
    where p.id = reviews.project_id
      and p.homeowner_auth_user_id = auth.uid()
      and p.status = 'completed'
  )
);

-- Aggregation maintenance is served via the contractor_ratings view.
-- Optionally create a materialized view and refresh job if needed.
