
/** React AuthContext for session and user.
 * Works with inline Babel/UMD React. Import via a <script type="text/babel"> after supabaseClient.js.
 * Usage:
 *   const { session, user } = React.useContext(AuthContext);
 */

const AuthContext = React.createContext({ session: null, user: null });

function AuthProvider({ children }) {
  const [session, setSession] = React.useState(null);
  React.useEffect(() => {
    window.sbClient.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = window.sbClient.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);
  const user = session?.user ?? null;
  return React.createElement(AuthContext.Provider, { value: { session, user } }, children);
}

// Expose to global for easy access in inline scripts
window.AuthContext = AuthContext;
window.AuthProvider = AuthProvider;
