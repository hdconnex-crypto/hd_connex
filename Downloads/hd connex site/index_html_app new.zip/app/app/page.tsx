
import HDConnexApp from '../components/hd-connex-app';

export default function HomePage() {
  return <HDConnexApp />;
}
