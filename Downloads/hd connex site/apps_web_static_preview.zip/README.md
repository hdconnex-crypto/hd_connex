# HDConnex Web

Single-file static site based on provided `index.html`. Phases are browsable at `/phases/index.html`.

## Preview locally
```bash
cd /mnt/data/project_under_test/merged/updated_site/updated/apps/web
python3 -m http.server 8000
# open http://localhost:8000
```
