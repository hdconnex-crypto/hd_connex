# Google Play Submission Checklist

## Policy coverage
- Restricted content, impersonation, IP, privacy, deception, device & network abuse.
  - TODO: Note any risky areas and how you mitigated them.
- Data safety form filled with exact practices. No mismatches with code.

## Target API requirements
- New apps and updates must target **Android 15 (API 35)** by **Aug 31, 2025**.
  - TODO: Set `targetSdkVersion = 35` and compile SDK to 35 in `build.gradle`.
- Platform exceptions: Wear OS/TV/Automotive have different targets.

## Store listing
- [ ] Accurate title, short & full description. No spammy keywords.
- [ ] Screenshots for phone and tablet. 7‑inch and 10‑inch recommended.
- [ ] Content rating questionnaire completed.
- [ ] Privacy policy URL reachable and consistent.
- [ ] App signing by Google Play enabled, or upload with the same keystore.

## Pre‑release
- [ ] Internal testing track configured. Invite testers by email list.
- [ ] Crash‑free sessions verified in Play Console pre‑launch report.
- [ ] Clear disclosure for sensitive permissions at runtime.

## Release
- [ ] Provide release notes. Explain major changes.
- [ ] Staged rollout configured (recommended).

References: Google Play Developer Policy Center and target API documentation.
