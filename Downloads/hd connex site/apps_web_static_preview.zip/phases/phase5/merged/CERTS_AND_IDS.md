# App Identifiers and Signing

## iOS
1. Create App ID in Apple Developer portal.
2. Create signing certificates (Apple Distribution).
3. Create Provisioning Profiles (App Store + any TestFlight needs).
4. In Xcode:
   - Set Bundle Identifier: `com.todo.hdconnex` (TODO).
   - Enable automatic signing or provide profiles.
5. App Store Connect:
   - Create the app record. Select correct platforms and bundle ID.

## Android
1. Choose final package name: `com.todo.hdconnex` (TODO).
2. Generate keystore:
```
keytool -genkeypair -v -storetype PKCS12 -keystore hdconnex.keystore -alias release -keyalg RSA -keysize 4096 -validity 3650
```
3. Store keystore securely. Add signing config in Gradle.
4. Enable Play App Signing (recommended) and upload signing key if prompted.

Security TODOs:
- Store keys in a secrets vault.
- Never commit keystores or provisioning profiles.
