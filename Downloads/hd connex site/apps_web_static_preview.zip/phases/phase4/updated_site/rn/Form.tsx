import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, AccessibilityInfo } from 'react-native';
import { ui } from './Styles';
export default function LeadForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState<{name?:string; email?:string}>({});
  function validate() {
    const e:any = {};
    if (!name) e.name = 'Name is required';
    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) e.email = 'Enter a valid email';
    setErrors(e);
    if (Object.keys(e).length) { AccessibilityInfo.announceForAccessibility('Please fix form errors'); return false; }
    return true;
  }
  return (
    <View accessible accessibilityLabel="Project lead form" style={ui.container}>
      <Text style={ui.h1}>Get matched</Text>
      <View>
        <Text>Name</Text>
        <TextInput accessibilityLabel="Full name" style={[ui.input, errors.name && ui.inputInvalid]} value={name} onChangeText={setName} />
        {errors.name ? <Text accessibilityRole="alert">{errors.name}</Text> : null}
      </View>
      <View>
        <Text>Email</Text>
        <TextInput accessibilityLabel="Email address" keyboardType="email-address" autoCapitalize="none" style={[ui.input, errors.email && ui.inputInvalid]} value={email} onChangeText={setEmail} />
        {errors.email ? <Text accessibilityRole="alert">{errors.email}</Text> : null}
      </View>
      <Pressable accessibilityRole="button" onPress={validate} style={[ui.button, ui.buttonPrimary]}>
        <Text>Submit</Text>
      </Pressable>
    </View>
  );
}