
const { useId, useState, useEffect, useRef } = React;
function VisuallyHidden({ as:Comp='span', children }) {
  const style = { position:'absolute', clip:'rect(0 0 0 0)', clipPath:'inset(50%)', width:'1px', height:'1px', overflow:'hidden', whiteSpace:'nowrap', border:0, padding:0, margin:-1 };
  return React.createElement(Comp, { style }, children);
}
function SkipLink({ targetId='main' }) { return React.createElement('a', { href: `#${targetId}`, className: 'skip-link' }, 'Skip to content'); }
function FormField({ id, label, type='text', value, onChange, required=false, describedBy, error, inputProps={} }) {
  const fieldId = id || (Math.random().toString(36).slice(2));
  const descId = describedBy ? `${fieldId}-desc` : undefined;
  const errId = error ? `${fieldId}-err` : undefined;
  const ariaDescribedBy = [descId, errId].filter(Boolean).join(' ') || undefined;
  return (
    React.createElement('div', { className:'space-y-1' },
      React.createElement('label', { htmlFor: fieldId, className:'block font-semibold text-gray-700' }, label, required ? React.createElement('span', { 'aria-hidden': true, className:'text-red-600 ml-1' }, '*') : null),
      describedBy ? React.createElement('div', { id: descId, className:'text-sm text-gray-500' }, describedBy) : null,
      React.createElement('input', { id: fieldId, type, value, onChange, required, 'aria-invalid': !!error || undefined, 'aria-describedby': ariaDescribedBy, className:'w-full p-3 border-2 border-gray-200 rounded-xl bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-100', ...inputProps }),
      error ? React.createElement('div', { id: errId, role:'alert', className:'text-sm mt-1' }, error) : null
    )
  );
}
function DialogA11y({ open, onClose, title='Dialog', children }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement;
    const el = ref.current;
    if (el) {
      const focusable = el.querySelectorAll('a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])');
      if (focusable.length) focusable[0].focus();
    }
    function onKey(e){ if (e.key === 'Escape') onClose?.(); }
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('keydown', onKey); prev && prev.focus && prev.focus(); };
  }, [open]);
  if (!open) return null;
  return React.createElement('div', { className:'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50', role:'dialog', 'aria-modal':'true', 'aria-label': title },
    React.createElement('div', { ref, className:'bg-white p-6 rounded-lg max-w-md mx-4' },
      React.createElement('div', { className:'flex items-center justify-between mb-4' },
        React.createElement('h3', { className:'text-xl font-bold', id:'dialog-title' }, title),
        React.createElement('button', { onClick:onClose, className:'px-2 py-1 rounded hover:bg-gray-100', 'aria-label':'Close dialog' }, '✕')
      ),
      children
    )
  );
}
window.AccessibleUI = { VisuallyHidden, SkipLink, FormField, DialogA11y };
