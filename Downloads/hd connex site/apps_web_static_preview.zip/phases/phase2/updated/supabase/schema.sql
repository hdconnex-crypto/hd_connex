
-- HD Connex Phase 2 — Supabase Postgres schema
-- NOTE: Run in Supabase SQL editor or as a migration.
-- TODO(security): Configure SMTP for auth email templates and domain before inviting users.

create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";

-- Roles reference: auth.users holds user identities. We mirror minimal profile data here.
create type public.user_role as enum ('homeowner','contractor','admin');
create type public.contractor_status as enum ('pending','approved','rejected');
create type public.lead_status as enum ('new','contacted','quoted','closed','archived');
create type public.project_status as enum ('proposal','active','completed','cancelled');

create table if not exists public.profiles (
  id uuid primary key default uuid_generate_v4(),   -- mirrors auth.users.id, but not 1:1 until user confirms email
  auth_user_id uuid unique,                         -- nullable until user authenticates
  role public.user_role not null default 'homeowner',
  full_name text,
  phone text,
  created_at timestamptz not null default now()
);

-- Contractors table. One row per contractor company. A contractor user can own exactly one company row.
create table if not exists public.contractors (
  id uuid primary key default uuid_generate_v4(),
  owner_auth_user_id uuid references auth.users(id) on delete set null,
  company_name text not null,
  license_number text not null,
  years_in_business int check (years_in_business >= 0),
  is_insured boolean not null default false,
  insurance_amount numeric(12,2),
  phone text,
  email text,
  website text,
  about text,
  specialties text[] default '{}',
  service_areas text[] default '{}', -- county names
  rating numeric(2,1) default 0.0 check (rating >= 0 and rating <= 5),
  total_reviews int default 0,
  status public.contractor_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists contractors_trgm_company on public.contractors using gin (company_name gin_trgm_ops);
create index if not exists contractors_gin_specialties on public.contractors using gin (specialties);
create index if not exists contractors_gin_areas on public.contractors using gin (service_areas);

-- Leads submitted by homeowners or anonymous users.
create table if not exists public.leads (
  id uuid primary key default uuid_generate_v4(),
  homeowner_auth_user_id uuid references auth.users(id) on delete set null,
  service text not null,
  county text not null,
  city text not null,
  details text,
  contact_name text not null,
  contact_email text not null,
  contact_phone text,
  sms_opt_out boolean not null default false,
  assigned_contractor_id uuid references public.contractors(id) on delete set null,
  status public.lead_status not null default 'new',
  created_at timestamptz not null default now()
);

-- Projects that originate from a lead.
create table if not exists public.projects (
  id uuid primary key default uuid_generate_v4(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  contractor_id uuid not null references public.contractors(id) on delete cascade,
  homeowner_auth_user_id uuid references auth.users(id) on delete set null,
  project_type text,
  status public.project_status not null default 'proposal',
  amount numeric(12,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Reviews left by homeowners after completion of a project.
create table if not exists public.reviews (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references public.projects(id) on delete cascade,
  contractor_id uuid not null references public.contractors(id) on delete cascade,
  homeowner_auth_user_id uuid references auth.users(id) on delete set null,
  rating smallint not null check (rating between 1 and 5),
  content text not null,
  verified boolean not null default true,
  created_at timestamptz not null default now()
);

-- Helper view to compute public contractor rating quickly.
create view public.contractor_ratings as
select
  c.id as contractor_id,
  round(avg(r.rating)::numeric, 1) as avg_rating,
  count(r.id) as total_reviews
from public.contractors c
left join public.reviews r on r.contractor_id = c.id
group by c.id;

-- Trigger to maintain updated_at
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists contractors_touch_updated_at on public.contractors;
create trigger contractors_touch_updated_at before update on public.contractors
for each row execute function public.touch_updated_at();

-- Seed helper table for allowed services (optional)
create table if not exists public.service_catalog (
  service text primary key
);
insert into public.service_catalog(service)
values
  ('Roofing'),('Landscaping'),('Concrete'),('Tree Service'),('Dock & Marine'),
  ('New Construction'),('Plumbing'),('Electrical'),('HVAC'),('Remodels'),
  ('Painting'),('Flooring'),('Pools'),('Fencing & Decks'),('Handyman'),
  ('Gutters'),('Windows & Doors')
on conflict do nothing;

-- TODO(data-integrity): consider check constraints to ensure county and city are whitelisted.
