
// Frontend: Thin API wrapper around Edge Functions and PostgREST.
// Assumes window.sbClient is available (from supabaseClient.js).
// All functions return {ok, ...} shapes for simplicity.

const baseFunctionsUrl = `${window.location.origin.replace(/:\d+$/, '')}`; // not used; functions have absolute URL
// TODO(env): Optionally set EDGE_BASE = 'https://YOUR-PROJECT.supabase.co/functions/v1'
export const EDGE_BASE = 'https://YOUR-PROJECT.supabase.co/functions/v1';
export const REST_BASE = 'https://YOUR-PROJECT.supabase.co/rest/v1';

export async function createLead(payload) {
  const res = await fetch(`${EDGE_BASE}/upsert_lead`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

export async function searchContractors({ service, county, q } = {}) {
  const url = new URL(`${EDGE_BASE}/search_contractors`);
  if (service) url.searchParams.set('service', service);
  if (county) url.searchParams.set('county', county);
  if (q) url.searchParams.set('q', q);
  const res = await fetch(url.toString());
  return res.json();
}

export async function getContractorById(id) {
  const { data, error } = await window.sbClient.from('contractors').select('*').eq('id', id).single();
  if (error) return { ok: false, error: error.message };
  return { ok: true, contractor: data };
}

export async function listReviews(contractorId) {
  const { data, error } = await window.sbClient.from('reviews').select('*').eq('contractor_id', contractorId).order('created_at', { ascending: false }).limit(50);
  if (error) return { ok: false, error: error.message };
  return { ok: true, reviews: data };
}

export async function postReview({ project_id, contractor_id, rating, content }) {
  const session = (await window.sbClient.auth.getSession()).data.session;
  const token = session?.access_token;
  const res = await fetch(`${EDGE_BASE}/post_review`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify({ project_id, contractor_id, rating, content }),
  });
  return res.json();
}

// Auth helpers
export async function signUpWithEmail(email, password) {
  return window.sbClient.auth.signUp({ email, password });
}
export async function signInWithEmail(email, password) {
  return window.sbClient.auth.signInWithPassword({ email, password });
}
export async function signOut() {
  return window.sbClient.auth.signOut();
}
