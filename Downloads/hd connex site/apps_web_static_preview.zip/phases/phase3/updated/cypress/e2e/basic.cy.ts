describe('Homepage', () => {
  it('loads and shows brand', () => {
    cy.visit('/');
    cy.contains(/HD CONNEX/i).should('exist'); // TODO: ensure server serves index page with this text
  });
});
