module.exports = {
  root: true,
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaVersion: "latest",
    sourceType: "module",
    ecmaFeatures: { jsx: true },
    project: false
  },
  plugins: ["@typescript-eslint", "react", "react-hooks", "react-native"],
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
    "plugin:react-native/all",
    "prettier"
  ],
  rules: {
    "react/react-in-jsx-scope": "off",
    "@typescript-eslint/no-unused-vars": ["warn", { "argsIgnorePattern": "^_", "varsIgnorePattern": "^_" }]
  },
  settings: { react: { version: "detect" } },
  ignorePatterns: ["node_modules/", "dist/", "build/"],
  overrides: [
    { "files": ["**/*.native.*", "mobile/**/*"], "env": { "react-native/react-native": true } },
    { "files": ["**/*.test.*", "**/*.spec.*"], "rules": { "@typescript-eslint/no-explicit-any": "off" } }
  ]
};
